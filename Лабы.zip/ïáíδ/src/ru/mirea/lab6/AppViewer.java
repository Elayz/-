package ru.mirea.lab6;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class AppViewer extends JFrame {
    JPanel[] pnl = new JPanel[9];
    JFrame window;
    MouseListener mouse = new MouseAdapter() {
        public void mouseEntered(MouseEvent e) {
            if (e.getSource() == pnl[4]) JOptionPane.showMessageDialog(window, "Добро пожаловать в");
            else if (e.getSource() == pnl[1]) JOptionPane.showMessageDialog(window, "Добро пожаловать в NORTH");
            else if (e.getSource() == pnl[7]) JOptionPane.showMessageDialog(window, "Добро пожаловать Абха");
            else if (e.getSource() == pnl[5]) JOptionPane.showMessageDialog(window, "Добро пожаловать в Дахране");
            else if (e.getSource() == pnl[3]) JOptionPane.showMessageDialog(window, "Добро пожаловать в Джидда");
        }
    };

    public AppViewer() {

        this.setSize(500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 3));

        for (int i = 0; i < pnl.length; i++) {
            int r = (int) (Math.random() * 255);
            int b = (int) (Math.random() * 255);
            int g = (int) (Math.random() * 255);
            pnl[i] = new JPanel();
            pnl[i].setBackground(new Color(r, g, b));
            add(pnl[i]);
        }

        pnl[1].setLayout(new BorderLayout());
        pnl[1].add(new JLabel("NORTH"), BorderLayout.CENTER);
        pnl[1].addMouseListener(mouse);

        pnl[4].setLayout(new BorderLayout());
        pnl[4].add(new JLabel("CENTER"), BorderLayout.CENTER);
        pnl[4].addMouseListener(mouse);

        pnl[7].setLayout(new BorderLayout());
        pnl[7].add(new JLabel("SOUTH"), BorderLayout.CENTER);
        pnl[7].addMouseListener(mouse);


        pnl[3].setLayout(new BorderLayout());
        pnl[3].add(new JLabel("WEST"), BorderLayout.CENTER);
        pnl[3].addMouseListener(mouse);

        pnl[5].setLayout(new BorderLayout());
        pnl[5].add(new JLabel("EAST"), BorderLayout.CENTER);
        pnl[5].addMouseListener(mouse);
    }
}
