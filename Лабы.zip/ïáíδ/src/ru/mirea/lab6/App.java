package ru.mirea.lab6;

public class App {
    public static void main(String[] args) {
        new AppViewer().setVisible(true);
    }
}
