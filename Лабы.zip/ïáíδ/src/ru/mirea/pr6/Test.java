package ru.mirea.pr6;


import java.lang.reflect.Array;

public class Test {
    public static void main(String[] args) {
        Student[] iDNumber1 = new Student[]{
                new Student("Студент1", 4),
                new Student("Студент2", 3),
                new Student("Студент3", 5),
        };
        Student[] iDNumber2 = new Student[]{
                new Student("Студент6", 2),
                new Student("Студент5", 3),
                new Student("Студент4", 1),
        };

        Student[] iDNumber = (Student[]) Array.newInstance(iDNumber1.getClass().getComponentType(), iDNumber1.length + iDNumber2.length);
        System.arraycopy(iDNumber1, 0, iDNumber, 0, iDNumber1.length);
        System.arraycopy(iDNumber2, 0, iDNumber, iDNumber1.length, iDNumber2.length);

        //SortingStudentsByGPA.sortQ(iDNumber, 0, iDNumber.length - 1);
        MergeSorter.sort(iDNumber, new Student("", 0));
        for (var x : iDNumber) {
            System.out.println(x);
        }
    }
}
