package ru.mirea.lab1;

public class Array {
    int[] arr = new int[10];

    public Array() {
    }

    public Array(int[] arr) {
        this.arr = arr;
    }

    public void fillArray() {
        for (int i = 0; i < this.arr.length; i++) {
            this.arr[i] = (int) (Math.random() * 100);
        }
    }

    public void printArray() {
        for (int j : this.arr) {
            System.out.print(j + ",");
        }
        System.out.println();
    }

    public void sortArray() {
        for (int i = 0; i < this.arr.length; i++) {
            for (int j = 0; j < this.arr.length; j++) {
                if (this.arr[i] < this.arr[j]) {
                    int temp = this.arr[j];
                    this.arr[j] = this.arr[i];
                    this.arr[i] = temp;
                }
            }
        }
    }
}
