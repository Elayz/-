package ru.mirea.lab1;

public class Main {
    public static void main(String[] args) {

        Array arrClass = new Array();
        arrClass.fillArray();
        arrClass.printArray();
        arrClass.sortArray();
        arrClass.printArray();


    }
}
