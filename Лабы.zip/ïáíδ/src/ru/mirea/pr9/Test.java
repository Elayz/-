package ru.mirea.pr9;

public class Test {
    public static void main(String[] args) {
        Student[] iDNumber = new Student[]{
                new Student("Иван", 4),
                new Student("Алексей", 3),
                new Student("Александр", 4),
                new Student("Марина", 5),
        };

        //SortingStudentsByGPA.sortQ(iDNumber, 0, iDNumber.length - 1);

        new App(iDNumber);

        /*
        try {
            System.out.println(Student.findStudents("Ал", iDNumber));
        } catch (StudentNotFoundException e) {
            e.printStackTrace();
        }
         */

        /*
        for (var x : iDNumber) {
            System.out.println(x);
        }
        */
    }
}
