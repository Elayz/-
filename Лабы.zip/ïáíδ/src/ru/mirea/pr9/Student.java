package ru.mirea.pr9;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class Student implements Comparator<Student> {

    private String name;
    private int grade;

    public Student(String name, int grade) {
        this.name = name;
        this.grade = grade;
    }

    @Override
    public int compare(Student o1, Student o2) {
        return Integer.compare(o2.grade, o1.grade);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }


    public static List<Student> findStudents(String name, Student[] students) throws StudentNotFoundException {
        List<Student> found_students = new ArrayList<Student>();
        boolean found = false;

        for (Student student : students) {
            if (student.name.toLowerCase().lastIndexOf(name.toLowerCase()) >= 0) {
                found = true;
                found_students.add(student);
            }
        }

        if (found) {
            return found_students;
        } else throw new StudentNotFoundException("No such student");
    }


    @Override
    public String toString() {
        return "SortingStudentsByGPA{" +
                "name='" + name + '\'' +
                ", grade=" + grade +
                '}';
    }
}
