package ru.mirea.pr9;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

public class App extends JFrame {
    private JTextField searchInput;
    private JButton searchButton;
    private JButton showListButton;
    private JButton sortListButton;
    private TableModel model;
    private JTable table;
    private JScrollPane jsp;
    private String[] columnNames = {"Имя", "Оценка"};
    private Student[] elements;
    private Object[][] rowData = {};


    public static Object[][] studentsToObject(Student[] students) {
        Object[][] rowData = new Object[students.length][2];

        for (int i = 0; i < students.length; i++) {
            rowData[i][0] = students[i].getName();
            rowData[i][1] = students[i].getGrade();
        }

        return rowData;
    }

    public App(Student[] students) {
        elements = students;
        searchInput = new JTextField(15);
        searchButton = new JButton("Найти");

        showListButton = new JButton("Показать");

        sortListButton = new JButton("Отсортировать");


        model = new DefaultTableModel(rowData, columnNames);
        table = new JTable(model);
        setLayout(new FlowLayout(FlowLayout.CENTER));
        jsp = new JScrollPane(table);


        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String searchText = searchInput.getText();
                    if (searchText.isEmpty()) {
                        throw new EmptyStringException("Search text is empty");
                    }

                    rowData = studentsToObject(Student.findStudents(searchText, elements).toArray(new Student[0]));
                    model = new DefaultTableModel(rowData, columnNames);
                    table.setModel(model);

                } catch (EmptyStringException es) {
                    JOptionPane.showMessageDialog(null, "Введите текст поиска");
                } catch (StudentNotFoundException snf) {
                    JOptionPane.showMessageDialog(null, "Студент не найден");
                }
            }
        });

        showListButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rowData = studentsToObject(elements);
                model = new DefaultTableModel(rowData, columnNames);
                table.setModel(model);
            }
        });

        sortListButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SortingStudentsByGPA.sortQ(elements, 0, elements.length - 1);
            }
        });


        add(searchInput);
        add(searchButton);


        add(jsp);
        add(showListButton, BorderLayout.SOUTH);
        add(sortListButton, BorderLayout.SOUTH);


        setSize(475, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

}
