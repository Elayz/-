package ru.mirea.pr5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MaxCount {
    ArrayList<Integer> numbers = new ArrayList<Integer>();

    public MaxCount() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String number;
        do {
            number = reader.readLine();
            this.numbers.add(Integer.parseInt(number));
        } while (!number.equals("0"));
        System.out.println(numberCounter(0, 0, getMaxNumber()));
    }

    public int getMaxNumber() {
        int max = numbers.get(0);
        for (int i = 0; i < numbers.size(); i++) {
            int t = numbers.get(i);
            if (t > max) {
                max = t;
            }
        }
        return max;
    }

    public int numberCounter(int i, int counter, int number) {
        if (this.numbers.get(i).equals(number)) {
            counter++;
        }
        if (i >= numbers.size() - 1) {
            return counter;
        }
        i++;
        return numberCounter(i, counter, number);
    }
}
