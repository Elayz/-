package ru.mirea.pr5;

import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        //new Digits().printDigit(1234);
        //new DigitsRigthToLeft().printDigit(1234);
        new MaxCount();
    }
}
