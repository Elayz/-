package ru.mirea.pr5;

public class Digits {


    public Digits() {

    }


    public void printDigit(int number) {
        if (number < 10) {
            System.out.println(number);
        } else {
            printDigit(number / 10);
            System.out.println(number % 10);
        }
    }
}
