package ru.mirea.pr5;

public class DigitsRigthToLeft {
    public DigitsRigthToLeft() {

    }

    public void printDigit(int number) {
        System.out.println(number % 10);
        if (number / 10 > 0) {
            printDigit(number / 10);
        }
    }
}
