package ru.mirea.lab7;

import java.util.LinkedList;

public class App {
    public static void main(String[] args) {
        LinkedList<Student> students = new LinkedList<>();
        students.add(new Student("Ivan", 19, "IKBO"));
        students.addFirst(new Student("Maxim", 20, "ISBO"));
        students.offerFirst(new Student("Anna", 19, "IVBO"));

        students.addLast(new Student("Denis", 19, "IKBO"));
        students.offerLast(new Student("Alex", 19, "IKBO"));


        students.add(1, new Student("Anton", 20, "IKBO"));
        students.add(new Student("Ilya", 19, "IKBO"));

        for (int i = 0; i < students.size(); i++) {
            System.out.println(students.get(i));
        }
    }
}
