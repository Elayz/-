package ru.mirea.lab10;

import java.util.ArrayList;
import java.util.Arrays;

public class Convert {
    public static <E> void toList(E[] arr, ArrayList<E> list) {
        list.addAll(Arrays.asList(arr));
    }

    public static void main(String[] args) {
        Integer[] array = {20, 1, 40, 55, 34};
        ArrayList<Integer> list = new ArrayList<Integer>();
        toList(array, list);
        System.out.println(list);


        String[] array2 = {"t2w", "end", "shoot", "trim"};
        ArrayList<String> list2 = new ArrayList<String>();
        toList(array2, list2);
        System.out.println(list2);
    }
}
