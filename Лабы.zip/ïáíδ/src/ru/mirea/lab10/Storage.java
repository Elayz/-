package ru.mirea.lab10;

import java.util.Arrays;

public class Storage<E> {

    private int size;
    private Object[] elements;

    public Storage(int size) {
        elements = new Object[size];
        this.size = 0;
    }

    public void add(E e) {
        if (size < elements.length) {
            elements[size] = e;
        } else {
            Object[] temp = elements;
            elements = new Object[size + 1];
            elements = temp;
            elements[size] = e;
        }
        size++;
    }

    public E get(int index) {
        if (index >= size)
            throw new IndexOutOfBoundsException("Index: " + index + " Size:" + size);

        return (E) elements[index];
    }

    public int getSize() {
        return size;
    }

    @Override
    public String toString() {
        return "Storage{" +
                "size=" + size +
                ", elements=" + Arrays.toString(elements) +
                '}';
    }

    public static void main(String[] args) {
        int a = 20;
        int b = 55;
        long c = 170;
        long d = -160;
        String test = "test";
        Storage<Object> list = new Storage<Object>(5);
        list.add(a);
        list.add(b);
        list.add(c);
        list.add(d);
        list.add(test);
        System.out.println(list.get(3));
        //list.add(d);
        //list.add(d);
        System.out.println(list);
    }

}
