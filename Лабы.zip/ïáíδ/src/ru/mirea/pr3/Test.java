package ru.mirea.pr3;

public class Test {
    public static void main(String[] args) {
        Shape s1 = new Circle(5.5, "RED", false);
        System.out.println(s1);
        System.out.println(s1.getArea());
        System.out.println(s1.getPerimeter());
        System.out.println(s1.getColor());
        System.out.println(s1.isFilled());
        //System.out.println(1.getRadius());// s1 – класса Shape, в нём нет метода getRadius (Circle)


        Circle c1 = (Circle) s1;
        System.out.println(c1);
        System.out.println(c1.getArea());
        System.out.println(c1.getPerimeter());
        System.out.println(c1.getColor());
        System.out.println(c1.isFilled());
        System.out.println(c1.getRadius());

        //Shape s2 = new Shape(); //Нельзя отдельно создать абстрактный класс

        Shape s3 = new Rectangle(1.0, 2.0, "RED", false);
        System.out.println(s3);
        System.out.println(s3.getArea());
        System.out.println(s3.getPerimeter());
        System.out.println(s3.getColor());
        //System.out.println(s3.getLength());// s3 – класса Shape, в нём нет метода getLength (Rectangle)

        Rectangle r1 = (Rectangle) s3;
        System.out.println(r1);
        System.out.println(r1.getArea());
        System.out.println(r1.getColor());
        System.out.println(r1.getLength());

        Shape s4 = new Square(6.6);
        System.out.println(s4);
        System.out.println(s4.getArea());
        System.out.println(s4.getColor());
        //System.out.println(s4.getSide());// s4 – класса Shape, в нём нет метода getSide (Square)

        Square sqr5 = (Square)s4;

        Rectangle r2 = (Rectangle) s4;
        System.out.println(r2);
        System.out.println(r2.getArea());
        System.out.println(r2.getColor());
        //System.out.println(r2.getSide());// s4 – класса Rectangle, в нём нет метода getSide (Square)
        System.out.println(r2.getLength());

        Square sq1 = (Square) r2;
        System.out.println(sq1);
        System.out.println(sq1.getArea());
        System.out.println(sq1.getColor());
        System.out.println(sq1.getSide());
        System.out.println(sq1.getLength());


        System.out.println("––––––");
        MovableCircle mc1 = new MovableCircle(0, 0, 5, 2, 6);
        System.out.println(mc1);
        mc1.moveUp();
        mc1.moveRight();
        System.out.println(mc1);

        System.out.println("––––––");
        MovableRectangle mr1 = new MovableRectangle(0, 0, 5, 10, 5, 6);
        System.out.println(mr1);
        mr1.moveUp();
        mr1.moveRight();
        System.out.println(mr1);

    }
}
