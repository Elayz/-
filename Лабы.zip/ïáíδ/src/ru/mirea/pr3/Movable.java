package ru.mirea.pr3;

public interface Movable {
    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();
}
