package ru.mirea.lab9;

import java.util.Scanner;

public class ThrowsDemo {
    public static void main(String[] args) {
        ThrowsDemo t = new ThrowsDemo();
        t.getKey();
    }

    public void getKey() {
        Scanner myScanner = new Scanner(System.in);
        System.out.print("Enter Key ");

        boolean is_exception = true;
        do {
            String key = myScanner.nextLine();
            try {
                is_exception = false;
                printDetails(key);
            } catch (Exception e) {
                is_exception = true;
                System.out.println("Exception, try again");
            }
        } while (is_exception);

    }

    public void printDetails(String key) throws Exception {
        String message = getDetails(key);
        System.out.println(message);
    }

    private String getDetails(String key) throws Exception {
        if (key.equals("")) {
            throw new Exception("Key set to empty string");
        }
        return "data for " + key;
    }
}