package ru.mirea.lab11;

import java.util.*;

public class Solution {

    public static <T> ArrayList<T> newArrayList(T... elements) {

        return new ArrayList<>(Arrays.asList(elements));
    }

    public static <T> HashSet<T> newHashSet(T... elements) {

        return new HashSet<>(Arrays.asList(elements));
    }

    public static <K, V> HashMap<K, V> newHashMap(List<? extends K> keys, List<? extends V> values) {
        if (keys.size() != values.size())
            throw new IllegalArgumentException();
        HashMap<K, V> map = new HashMap<>();
        for (int i = 0; i < keys.size(); i++) {
            map.put(keys.get(i), values.get(i));
        }
        return map;
    }

    public static void main(String[] args) {
        ArrayList<Integer> arr = newArrayList(27, 19);
        HashSet<Integer> set = newHashSet(10, 15);
        List<Integer> lst1 = newArrayList(1, 2);
        List<String> lst2 = newArrayList("apple", "29");
        HashMap<Integer, String> map = newHashMap(lst1, lst2);
        System.out.println(arr);
        System.out.println(set);
        System.out.println(map);
    }
}
