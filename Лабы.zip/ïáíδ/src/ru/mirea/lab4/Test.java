package ru.mirea.lab4;

/*
Вараинт 2.
Реализовать интерфейс Priceable, имеющий метод getPrice(), возвращающий некоторую цену для объекта.
Проверить работу для различных классов, сущности которых могут иметь цену.
 */
public class Test {
    public static void main(String[] args) {
        Priceable book = new Book(1500);
        Priceable phone = new Phone(110000);

        System.out.println(book);
        System.out.println(phone);
    }
}
