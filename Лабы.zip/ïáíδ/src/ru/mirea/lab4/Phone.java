package ru.mirea.lab4;

public class Phone implements Priceable {
    private int price;

    public Phone(int price) {
        this.price = price;
    }

    @Override
    public int getPrice() {
        return this.price;
    }

    @Override
    public String toString() {
        return "Phone{" +
                "price=" + price +
                '}';
    }
}
