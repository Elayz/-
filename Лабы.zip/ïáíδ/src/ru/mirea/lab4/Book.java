package ru.mirea.lab4;

public class Book implements Priceable {
    private int price;

    public Book(int price) {
        this.price = price;
    }

    @Override
    public int getPrice() {
        return this.price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "price=" + price +
                '}';
    }
}
