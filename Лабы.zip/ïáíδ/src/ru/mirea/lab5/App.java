package ru.mirea.lab5;

public class App {
    public static String path;

    public static void main(String[] args) {
        path = args[0];
        new PictureViewer().setVisible(true);
    }
}
