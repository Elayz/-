package ru.mirea.lab5;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Picture extends JPanel {
    public BufferedImage image;

    public Picture() {
        try {
            image = ImageIO.read(new File(App.path));
        } catch (IOException ex) {
            System.out.println("Ошибка: изображение не найдено");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 10, 10, this);
    }

}
