package ru.mirea.lab5;


import javax.swing.*;

public class PictureViewer extends JFrame {
    public PictureViewer() {
        Picture comp = new Picture();
        add(comp);
        this.setSize(comp.image.getWidth(null) + 50, comp.image.getHeight(null) + 50);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
