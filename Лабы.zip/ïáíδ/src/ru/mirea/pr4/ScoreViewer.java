package ru.mirea.pr4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ScoreViewer extends JFrame {

    String teamOneLabel = "teamOne";
    String teamTwoLabel = "teamTwo";
    String lastScorer = "N/A";

    int teamOneScore = 0;
    int teamTwoScore = 0;

    JLabel scoreLabel = new JLabel("Result: 0 X 0", SwingConstants.CENTER);
    JButton teamOneButton = new JButton("teamOneLabel");
    JButton teamTwoButton = new JButton("teamTwoLabel");
    JLabel lastScorerLabel = new JLabel("Last Scorer: N/A", SwingConstants.CENTER);
    JLabel winnerLabel = new JLabel("Winner: DRAW", SwingConstants.CENTER);
    JPanel centerPanel = new JPanel();
    JPanel bottomPanel = new JPanel();

    public ScoreViewer() {
        run();
    }

    public ScoreViewer(String teamOneLabel, String teamTwoLabel) {
        this.teamOneLabel = teamOneLabel;
        this.teamTwoLabel = teamTwoLabel;
        run();
    }

    public void run() {
        this.setSize(300, 300);


        this.teamOneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                teamOneScore++;
                lastScorer = teamOneLabel;
                update();
            }
        });

        this.teamTwoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                teamTwoScore++;
                lastScorer = teamTwoLabel;
                update();
            }
        });

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.centerPanel.setLayout(new FlowLayout());
        this.centerPanel.add(teamOneButton);
        this.centerPanel.add(teamTwoButton);

        this.bottomPanel.setLayout(new GridLayout(2, 1));
        this.bottomPanel.add(this.lastScorerLabel);
        this.bottomPanel.add(this.winnerLabel);

        this.teamOneButton.setText(this.teamOneLabel);
        this.teamTwoButton.setText(this.teamTwoLabel);

        add(this.scoreLabel, BorderLayout.NORTH);
        add(this.centerPanel, BorderLayout.CENTER);
        add(this.bottomPanel, BorderLayout.SOUTH);
        this.update();
    }

    public void update() {
        this.scoreLabel.setText("Result: " + this.teamOneScore + " X " + this.teamTwoScore);
        if (this.teamOneScore == this.teamTwoScore) {
            this.winnerLabel.setText("Winner: DRAW");
        } else {
            this.winnerLabel.setText("Winner: " + (this.teamOneScore > this.teamTwoScore ? this.teamOneLabel : this.teamTwoLabel));
        }
        this.lastScorerLabel.setText("Last Scorer: " + this.lastScorer);
    }
}
