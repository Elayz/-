package ru.mirea.pr7;

public class Game {
    private final Player firstPlayer;
    private final Player secondPlayer;
    private int moves;
    private boolean isBotva = true;

    public Game(Player p1, Player p2) {
        firstPlayer = p1;
        secondPlayer = p2;
    }

    public void start() {
        for (moves = 1; moves < 106; moves++) {
            iteration();
            if (firstPlayer.isLose() || secondPlayer.isLose()) {
                isBotva = false;
                break;
            }
        }
        end();
    }

    public void end() {
        System.out.println(isBotva ? "botva" : (firstPlayer.isLose() ? secondPlayer : firstPlayer).getName() + moves);
    }

    private void iteration() {
        if (isFirstWin()) {
            firstPlayer.winIteration(firstPlayer.getCard(), secondPlayer.getCard());
        } else {
            secondPlayer.winIteration(firstPlayer.getCard(), secondPlayer.getCard());
        }
    }

    private boolean isFirstWin() {
        Integer f1 = firstPlayer.getCardValue();
        Integer f2 = secondPlayer.getCardValue();
        return ((f1 == 0 || f1 == 9) && (f2 == 0 || f2 == 9)) ? f1 < f2 : f1 > f2;
    }
}
