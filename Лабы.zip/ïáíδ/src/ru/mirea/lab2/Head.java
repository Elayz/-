package ru.mirea.lab2;

public class Head {
    public boolean isBold;
    public String eyeColor;

    public Head() {
        this.isBold = false;
        this.eyeColor = "Green";
    }

    public Head(boolean isBold, String eyeColor) {
        this.isBold = isBold;
        this.eyeColor = eyeColor;
    }

    public boolean isBold() {
        return this.isBold;
    }

    public void setBold(boolean bold) {
        this.isBold = bold;
    }

    public String getEyeColor() {
        return this.eyeColor;
    }

    public void setEyeColor(String eyeColor) {
        this.eyeColor = eyeColor;
    }

    @Override
    public String toString() {
        return "Head{" +
                "isBold=" + isBold +
                ", eyeColor='" + eyeColor + '\'' +
                '}';
    }
}
