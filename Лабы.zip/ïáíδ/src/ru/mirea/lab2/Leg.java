package ru.mirea.lab2;

public class Leg {
    public int size;

    public Leg() {
        this.size = 40;
    }

    public Leg(int size) {
        this.size = size;
    }

    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "Leg{" +
                "size=" + size +
                '}';
    }
}
