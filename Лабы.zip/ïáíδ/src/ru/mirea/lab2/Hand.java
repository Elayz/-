package ru.mirea.lab2;

public class Hand {
    public int fingersCount;

    public Hand() {
        this.fingersCount = 5;
    }

    public Hand(int fingersCount) {
        this.fingersCount = fingersCount;
    }

    public int getFingersCount() {
        return this.fingersCount;
    }

    public void setFingersCount(int fingersCount) {
        this.fingersCount = fingersCount;
    }

    @Override
    public String toString() {
        return "Hand{" +
                "fingersCount=" + fingersCount +
                '}';
    }
}
