package ru.mirea.lab2;

public class Human {
    public static void main(String[] args) {
        Head head = new Head();

        Hand hand_rigth = new Hand(5);
        Hand hand_left = new Hand(4);

        Leg leg = new Leg();

        System.out.println(head);
        System.out.println(hand_rigth);
        System.out.println(hand_left);
        System.out.println(leg);
    }
}
