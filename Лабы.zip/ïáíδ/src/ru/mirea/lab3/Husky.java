package ru.mirea.lab3;

public class Husky extends Dog {

    public Husky() {
        super(1, false);
    }

    public Husky(int weight, boolean sex) {
        super(weight, sex);
    }

    @Override
    protected String getColor() {
        return "White";
    }

    @Override
    public String toString() {
        return "Husky{" +
                "weight=" + weight +
                ", color='" + getColor() + '\'' +
                ", sex=" + sex +
                '}';
    }
}
