package ru.mirea.lab3;

public class Pitbull extends Dog {

    public Pitbull() {
        super(2, true);
    }

    public Pitbull(int weight, boolean sex) {
        super(weight, sex);
    }

    @Override
    protected String getColor() {
        return "Black";
    }

    @Override
    public String toString() {
        return "Pitbull{" +
                "weight=" + weight +
                ", color='" + getColor() + '\'' +
                ", sex=" + sex +
                '}';
    }
}