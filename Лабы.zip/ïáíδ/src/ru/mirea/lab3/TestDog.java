package ru.mirea.lab3;

/*
Вариант 2.
Создать абстрактный класс, описывающий собак(Dog). С помощью наследования реализовать различные породы собак.
Протестировать работу классов.
 */

public class TestDog {
    public static void main(String[] args) {
        Dog[] dogs = new Dog[3];
        dogs[0] = new Husky(5, true);
        dogs[1] = new Pitbull(15, false);
        dogs[2] = new Husky(7, false);

        for (Dog DogItem : dogs)
            System.out.println(DogItem);
    }
}
