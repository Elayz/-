package ru.mirea.lab3;

public abstract class Dog {
    protected int weight;
    protected String color;
    protected boolean sex;

    Dog() {
    }

    public Dog(int weight, boolean sex) {
        this.weight = weight;
        this.sex = sex;
    }


    public boolean isMale() {
        return sex;
    }

    public int getWeight() {
        return weight;
    }

    protected abstract String getColor();
}
