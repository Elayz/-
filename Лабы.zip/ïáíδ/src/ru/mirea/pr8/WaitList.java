package ru.mirea.pr8;

import java.util.Collection;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Список ожидания
 *
 * @param <E> дженерик элемента
 */
public class WaitList<E> implements IWaitList<E> {

    protected ConcurrentLinkedQueue<E> content = new ConcurrentLinkedQueue<E>();

    /**
     * Конструктор
     */
    public WaitList() {

    }

    /**
     * Добавляет элементы коллекции в очередь
     *
     * @param c коллекция элементов
     */
    public WaitList(Collection<E> c) {
        this.content.addAll(c);
    }

    @Override
    public String toString() {
        return "WaitList{" +
                "content=" + this.content +
                '}';
    }

    /**
     * @see IWaitList#add(Object)
     */
    @Override
    public void add(E element) {
        this.content.add(element);
    }

    /**
     * @see IWaitList#remove()
     */
    @Override
    public E remove() {
        return this.content.poll();
    }

    /**
     * @see IWaitList#contains(Object)
     */
    @Override
    public boolean contains(E element) {
        return this.content.contains(element);
    }

    /**
     * @see IWaitList#containsAll(Collection)
     */
    @Override
    public boolean containsAll(Collection<E> c) {
        for (E e : c)
            if (!this.content.contains(e))
                return false;
        return true;
    }

    /**
     * @see IWaitList#isEmpty()
     */
    @Override
    public boolean isEmpty() {
        return this.content.isEmpty();
    }
}
