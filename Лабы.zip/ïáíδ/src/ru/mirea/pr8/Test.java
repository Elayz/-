package ru.mirea.pr8;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        ArrayList<Integer> arr = new ArrayList<Integer>();
        arr.add(1);             // [1]
        arr.add(5);             // [1,5]

        // WaitList
        WaitList<Integer> wl = new WaitList<Integer>(arr);

        wl.add(2);              // [1,5,2]

        wl.containsAll(arr);    // true

        wl.remove();            // [5,2]

        wl.contains(5);         // true
        wl.contains(1);         // false

        wl.isEmpty();           // false

        // BoundedWaitList
        BoundedWaitList<Integer> bwl = new BoundedWaitList<Integer>(2);
        bwl.add(3);
        bwl.add(1);
        bwl.add(5);             // List is full [3,1]

        bwl.remove();

        bwl.add(5);             // [4,5]
        bwl.containsAll(arr);   //true

        // UnfairWaitList
        UnfairWaitList<Integer> uwl = new UnfairWaitList<Integer>();
        uwl.add(2);
        uwl.add(5);
        uwl.add(1);             // [2,5,1]

        uwl.moveToBack(5);
        uwl.containsAll(arr);   // true [2,1,5]

        uwl.remove(5);  // [2,1]
        uwl.add(5);             // [2,1]

        uwl.remove(2);  // [2,1]
    }
}
