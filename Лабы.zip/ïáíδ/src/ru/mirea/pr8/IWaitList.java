package ru.mirea.pr8;

import java.util.Collection;

/**
 * Интерфейс списков ожидания
 *
 * @param <E> дженерик элемента
 */

public interface IWaitList<E> {

    /**
     * Добавление элемента
     *
     * @param element добавляемый элемент
     */

    void add(E element);

    /**
     * Удаление элемента
     *
     * @return удаленный элемент
     */
    E remove();

    /**
     * Проверка содержания элемента
     *
     * @param element искомый элемент
     * @return {@code true} если элемент содержится
     */
    boolean contains(E element);

    /**
     * Проверка содержания элементов
     *
     * @param c коллекция элементов
     * @return {@code true} если все элементы коллекции содержатся
     */
    boolean containsAll(Collection<E> c);

    /**
     * @return {@code true} если очередь пустая
     */
    boolean isEmpty();
}
