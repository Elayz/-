package ru.mirea.pr8;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Не честный список ожидания
 *
 * @param <E> дженерик элемента
 */
public class UnfairWaitList<E> extends WaitList<E> {

    private LinkedList<E> removedElements = new LinkedList<E>();

    /**
     * Конструктор
     */
    public UnfairWaitList() {
    }

    /**
     * Удаляет конкретный элемент
     *
     * @param element удаляемый элемент
     */
    public void remove(E element) {
        this.content.removeIf(e -> (e == element && this.content.peek() != element));
        removedElements.add(element);
    }

    /**
     * Добавление элемента, если он еще не был удален
     *
     * @param element удаляемый элемент
     */
    public void add(E element) {
        if (!removedElements.contains(element))
            super.add(element);
    }

    /**
     * Перемещает элемент в конец очереди
     *
     * @param element искомый элемент
     */
    public void moveToBack(E element) {
        for (E e : this.content) {
            if (e.equals(element)) {
                this.content.remove(e);
                this.content.add(e);
            }
        }

    }

}
