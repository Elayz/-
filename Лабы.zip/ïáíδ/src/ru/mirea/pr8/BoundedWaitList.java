package ru.mirea.pr8;

/**
 * Список с ограниченной ёмкостью
 *
 * @param <E> дженерик элемента
 */
public class BoundedWaitList<E> extends WaitList<E> {
    /**
     * Максимальный объем очереди
     */
    private int capacity;

    /**
     * Конструктор
     *
     * @param capacity {@link BoundedWaitList#capacity}
     */
    public BoundedWaitList(int capacity) {
        this.capacity = capacity;
    }

    /**
     * Возвращает {@link BoundedWaitList#capacity}
     *
     * @return максимальный объем очереди
     */
    public int getCapacity() {
        return this.capacity;
    }

    /**
     * Добавляет элементы коллекции в очередь, если это не превышает объем
     *
     * @param element добавляемый элемент
     */
    public void add(E element) {
        if (this.content.size() < this.capacity)
            this.content.add(element);
    }

    @Override
    public String toString() {
        return "BoundedWaitList{" +
                "capacity=" + capacity +
                ", content=" + content +
                '}';
    }
}
