package ru.mirea.pr1;

public class TestBall {
    public static void main(String[] args) {
        Ball b1 = new Ball("white", 3.5);
        Ball b2 = new Ball("black", 7);
        Ball b3 = new Ball("yellow");
        b3.setRadius(1.25);
        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);
        b1.getValue();
        b2.getValue();
        b3.getValue();
    }
}
