package ru.mirea.pr1;

public class Ball {
    private double radius;
    private String color;

    public Ball(String c, double r) {
        this.radius = r;
        this.color = c;
    }

    public Ball(String c) {
        this.color = c;
        this.radius = 1;
    }

    public Ball() {
        this.color = "Green";
        this.radius = 1;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getRadius() {
        return radius;
    }

    public String getColor() {
        return color;
    }

    public String toString() {
        return "Ball{" +
                "radius=" + radius +
                ", color='" + color + '\'' +
                '}';
    }

    public void getValue() {
        double value = (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
        System.out.println("Value is " + value);
    }
}
